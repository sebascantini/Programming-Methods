#ifndef _BACKTRACKING_HH_
#define _BACKTRACKING_HH_

#include "headers.h"

int backtracking(const info_t &info, const int mode = 2, int i = 0, int riesgo = 0, int beneficio = 0, int potencial = 0);

#endif