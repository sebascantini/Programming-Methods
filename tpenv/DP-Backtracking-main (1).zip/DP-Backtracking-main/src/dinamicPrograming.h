#ifndef _DINAMICPROGRAMING_HH_
#define _DINAMICPROGRAMING_HH_

#include "headers.h"

int dinamicPrograming(const info_t &info);

#endif