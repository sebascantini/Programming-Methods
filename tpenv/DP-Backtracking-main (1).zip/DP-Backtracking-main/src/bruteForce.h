#ifndef _BRUTEFORCE_HH_
#define _BRUTEFORCE_HH_

#include "headers.h"

int bruteForce(const info_t &info, int i = 0, bool valido = true, bool consecutivo = false, int riesgo = 0, int beneficio = 0);

#endif
